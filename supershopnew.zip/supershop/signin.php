
<?php
include "connection.php";
if (isset($_POST['submit'])) 
{
    $nam = $_POST['nam'];
    $birth = $_POST['dateofbirth'];
    $email = $_POST['email'];
    $pass = $_POST['password'];
    $cpass = $_POST['cpass'];
    $status = 0;
    if($pass != $cpass)
    {
         
        echo "incorrect password";
        
    }
    else{

    $sql =  "INSERT INTO users (name,  dateofbirth, email, password)
    VALUES ('$nam',   '$birth', '$email','$pass'); ";
    $go =mysqli_query($connect,$sql);
    if ($go) 
    {
        echo "registered successfuly";
    }
    else{
        echo"error!".mysqli_error($connect);
    }
    }
}

?>
<!DOCTYPE html>
<head>
    <title>Sign UP</title>
    <link rel="stylesheet" href="phpcss.css">
</head>
<div class= "box">
<body>
    <h1>Registration</h1>

    <form action="" method="post" class="login-form">
    <div class="textbox">
       
        <input type="text" name="dateofbirth" id="date"  placeholder="Name"required>><br>
      </div>

        <div class="textbox">
       
        <input type="date" name="dateofbirth" id="date"  placeholder="Date of birth"required>><br>
        </div>

        <div class="textbox">
        <input type="email" name="email" id="email" placeholder="Email"required>><br>
        </div>

        <div class="textbox">
        <input type="password"  name="password" id="pass" placeholder="Password"required>><br>
        </div>

        <div class="textbox">
        <input type="password" name="cpass" id="cpass" placeholder="Confirm Password" required><br>
        </div>


       
        <input type="submit" name="submit" id="submit"  class="btn"  required><br>
        
        <a href="login.php">Login</a> <br>

    
    </div> 
    </form> 
</body>
</html>
